<!DOCTYPE html>
<!-- Pierre Sénéchal | Augustin Mariage | Judith Lecoq | François Beaucour -->
<html lang="an">
<head>
<meta charset="utf-8">      
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="site.css">
<title> Sudoku Gang </title>
</head>
<body>
<!-- Footer page is used as the bottom of the "accueil" page, presenting who we are and more-->
<div class = "footersquare"><div class="footertext"><p></br>Sudo'Gang © </br> This website has been made by Pierre Sénéchal, Augustin Mariage, Judith Lecoq, François Beaucour, Abdelilah Dadague & Colin Olivier on may 2020.</p></div>
</br><div class = "share"><p>Share it with your friends !</p></div>
</br>
<div class="imagescontact">
<div class= "facebook"> <a href="https://www.facebook.com/"><img src="facebook.png"></a> </div>
<div class= "twitter"> <a href="https://twitter.com/"><img src="twitter.png"> </a></div>
<div class= "linkedin"> <a href="https://www.linkedin.com/"><img src="linkedin.png"> </a></div>
<div class= "whatsapp"> <a href="https://www.whatsapp.com/"><img src="whatsapp.png"> </a></div>
</div>
<div class="contact"><p>A problem with the website? You can contact us on social media at any time and we will work to solve it as soon as possible !</p></div>
<body>
