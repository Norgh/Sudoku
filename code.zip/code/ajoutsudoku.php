

<div align="right">
	<div class="recanglewtc"></div>
	<div class="textwtc"><p>Want to create your own sudoku?</p></div>
	<div class="createsudo" onclick='location.href="empty.php";'> Create my sudoku </div> <!-- Redirecting to the Sudoku creator page -->
</div>

<div align="right">
	<div class="texthelp"><p>Stuck?</p></div> 
	<div class="recanglehelp"></div>
	<div class="helpimg"><img src="help.png" width="30" height="30" alt="helpimg" ></div> <!-- The little image "help" that stands above the nice help button (a really useful one) -->
</div>
<div align="left">
<div class="engrenage"><p><img id="imgtourne" src="engrenage.png" alt="tourne" /></p></div>
<div class="engrenage1"><p><img width="70" height="70" id="imgtourne1" src="engrenage.png" alt="tourne" /></p></div>

